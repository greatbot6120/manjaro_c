#include <stdio.h>

#define N 5
#define UP 1
#define DOWN -1

void sortarr(int[], int, int);
void fillarr(int[], int);
int mixarr(int[], int[], int[], int);
int find(int[], int, int);

int main(int argc, char * argv[]) {
  int seq1[N], seq2[N], unione[N*2];
  int nu, i;

  fillarr(seq1, N);
  fillarr(seq2, N);

  /* unisco rimuovendo i doppioni e poi ordino */
  nu = mixarr(seq1, seq2, unione, N);

  for(i = 0; i < nu; i++)
    printf("%d ", unione[i]);
  printf("\n");

  return 0;
}

void sortarr(int v[], int dim, int updown) {
  int i, j;
  int tmp;

  if(updown == UP)
    for(i = 0; i < dim; i++)
      for(j = i+1; j < dim; j++)
        if(v[i] > v[j]) {
          tmp = v[i];
          v[i] = v[j];
          v[j] = tmp;
        }
  else if(updown == DOWN)
    for(i = 0; i < dim; i++)
      for(j = i+1; j < dim; j++)
        if(v[i] < v[j]) {
          tmp = v[i];
          v[i] = v[j];
          v[j] = tmp;
        }
}

void fillarr(int v[], int dim) {
  int i;
  for(i = 0; i < dim; i++)
    scanf("%d", &v[i]);
}

int mixarr(int v1[], int v2[], int u[], int dim) {
  int i, j, k, nu;
  int doppio;

  /* controllo che ciascun elemento di v1 e poi di v2
     non sia già presente in u, in caso positivo aggiungo
     in coda. NOTA: si potrebbe realizzare un ulteriore
     sottoprogramma ...*/
  nu = 0;
  for(i = 0; i < dim; i++){
  	if(!find(u, nu, v1[i])){
      u[nu] = v1[i];
      nu++;
    }
  }
  for(i = 0; i < dim; i++){
  	if(!find(u, nu, v2[i])){
      u[nu] = v2[i];
      nu++;
    }
  }
  sortarr(u, nu, UP);

  return nu;
}

int find(int v[], int dim, int val){
  int i, found;
  for(i = 0, found = 0; i < dim && !found; i++)
  	if(val == v[i])
      found = 1;
  return found;
}