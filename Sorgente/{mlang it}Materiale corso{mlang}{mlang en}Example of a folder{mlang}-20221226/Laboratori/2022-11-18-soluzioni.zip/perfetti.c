#include <stdio.h>

#define MAX_DIM 10
#define PERFETTO 1
#define ABBONDANTE 2
#define DIFETTIVO 3
#define NVAL 4
#define SYM '*'

int check(int);
void istogrammav(int [], int);

int main(int argc, char * argv[]) {
  int arr[MAX_DIM];
  int ris[MAX_DIM];
  int i;
  int num[NVAL];  /* per fare l'istogramma */
                  /* altrimenti tre variabili diverse */

  /*acquisizione valori*/
  for(i = 0; i < MAX_DIM; i++)
    scanf("%d", &arr[i]);

	/* inizializzazione contatori */
	for(i = 0; i < MAX_DIM; i++)
	  num[i] = 0;

  /*controllo e aggiornamento per ogni tipo*/
  for(i = 0; i < MAX_DIM; i++){
    if(arr[i] > 0){
      ris[i] = check(arr[i]);
/*
      if(ris[i] == PERFETTO)
        nperf++;
      else if(ris[i] == DIFETTIVO)
        ndif++;
      else if(ris[i] == ABBONDANTE)
        nab++;
*/
    } else
      ris[i] = 0;
		num[ris[i]]++;
  }

  /*stampo array ris */
  for(i = 0; i < MAX_DIM; i++)
    printf("%2d ", ris[i]);
	printf("\n");

	for(i = 0; i < NVAL; i++)
    printf("%2d", num[i]);
	printf("\n");

	istogrammav(&num[1], NVAL-1);

  return 0;
}

int check(int num) {
  int i, sumdiv;
	int ris;

  /*cerco divisori e ne calcolo la somma*/
  sumdiv = 0;
  for(i = 1; i < num; i++)
    if(num % i == 0)
      sumdiv += i;

  /*confronto somma divisori con numero*/
  if(sumdiv == num)
    ris = PERFETTO;
  else if(sumdiv > num)
    ris = ABBONDANTE;
  else
    ris =  DIFETTIVO;

  return ris;
}


void istogrammav(int v[], int dim) {
	int i;
	int max;
	int riga;

	/* trovo il valore massimo */
	max = v[0];
	for(i = 1; i < dim; i++)
		if(v[i] > max)
			max = v[i];

 	/* ogni riga */
	for(riga = 0; riga < max; riga++){
		/* ogni colonna */
		for(i = 0; i < dim; i++)
			if(riga + v[i] >= max)
				printf("%c", SYM);
			else
				printf(" ");
		printf("\n");
	}
}
