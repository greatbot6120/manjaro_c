#include <stdio.h>

#define N 20

int fillarrord(int[], int);
void viewarr(int[], int);

int main(int argc, char * argv[]) {
  int seq[N], num;
  int nord;

  do
    scanf("%d", &num);
  while (num < 1 || num > N);

  nord = fillarrord(seq, num);

  printf("%d\n", nord);
  viewarr(seq, nord);

  return 0;
}

int fillarrord(int v[], int dim) {
  int nletti, i;
  int val;

  /* primo elemento */
  scanf("%d", &v[0]);
  nletti = 1;
  i = 1;
  
  /* gli altri */
  do {
    scanf("%d", &val);
    if(val > v[i-1]) {
      v[i] = val;
      i++;
    }
    nletti++;
  } while (nletti < dim);
  return i;
}

void viewarr(int v[], int dim) {
  int i;

  for(i = 0; i < dim; i++)
    printf("%d ", v[i]);
  printf("\n");
}
