/* 
Si vuole realizzare un programma in C (C89) per la gestione di un archivio di album musicali (al massimo 100). Ogni album è caratterizzato da un titolo ed un autore (entrambe stringhe di al massimo 30 caratteri), un anno di pubblicazione, il numero di tracce, la durata complessiva (in termini di ore, minuti, secondi); infine, si vuole memorizzare anche il prezzo del album (un valore float). 
Definire un tipo di dato per rappresentare l'archivio di album. In seguito scrivere un programma che chiede all'utente prima il numero di album da inserire e poi i dati di ciascun album (assumendo che l'utente inserisca correttamente i dati). Il programma visualizza i dati del album di durata massima; se sono presenti più album di stessa durata massima il programma visualizzerà i dati del primo di essi (VARIANTE: il programma visualizza i dati di tutti gli album di durata massima, se ne sono stati trovati più di uno).
In seguito il programma chiede il nome di un autore e visualizza i titoli di tutti gli album pubblicati da questo. Infine il programma visualizza l'autore che ha pubblicato più album; se più autori autori hanno lo stesso numero massimo di album, si visualizzi il primo.
 */

#include<stdio.h>
#include<string.h>

#define MAXALBUM 100
#define MAXSTR 30
#define SH 3600
#define SM 60

typedef struct {
  int ore, min, sec;
} durata_t;

typedef struct {
  char titolo[MAXSTR+1], autore[MAXSTR+1];
  int anno;
  int tracce;
  durata_t durata;
  float prezzo;
} album_t;

typedef struct {
  album_t album[MAXALBUM];
  int nAlbum;
} archivio_t;

int main(){
  archivio_t arc;
  int i, imax, dmax, dcurr;
  char autore[MAXSTR+1];
  int j, conto, maxconto;
  
  do{
    scanf("%d", &arc.nAlbum);
  } while(arc.nAlbum <= 0);
  
  for(i=0; i<arc.nAlbum; i++){
    scanf(" %[^\n]", arc.album[i].titolo);
    scanf(" %[^\n]", arc.album[i].autore);
    scanf("%d %d %f", &arc.album[i].anno, &arc.album[i].tracce, &arc.album[i].prezzo);
    scanf("%d %d %d", &arc.album[i].durata.ore, &arc.album[i].durata.min, &arc.album[i].durata.sec);
  }
  
  imax = 0;
  dmax = arc.album[0].durata.ore * SH + arc.album[0].durata.min * SM + arc.album[0].durata.sec;
  for(i = 1; i < arc.nAlbum; i++){
    dcurr = arc.album[i].durata.ore * SH + arc.album[i].durata.min * SM + arc.album[i].durata.sec;
    if(dcurr > dmax){
      dmax = dcurr;
      imax = i;
    }
  }
  
  printf("%s - %s\n", arc.album[imax].titolo, arc.album[imax].autore);

  scanf(" %[^\n]", autore);
  for(i = 0; i < arc.nAlbum; i++){
    if(strcmp(autore, arc.album[i].autore) == 0)
      printf("%s %s\n", autore, arc.album[i].titolo);
  }

  for(i = 0, maxconto = 0; i < arc.nAlbum; i++){
    for(j = i, conto = 0; j < arc.nAlbum; j++){
      if(strcmp(arc.album[i].autore, arc.album[j].autore) == 0)
        conto++;
    }
    if(conto > maxconto){
      maxconto = conto;
      strcpy(autore, arc.album[i].autore);
    }
  }
  printf("%s\n", autore);

  return 0;
}
