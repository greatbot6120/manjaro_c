#include <stdio.h>
#define MAX_ELEM 100

int cercasomma(int, int[], int);

int main(int argc, char * argv[]) {
  int v[MAX_ELEM], dim, k;
  int ris;

  dim = 0;
  scanf("%d", &v[dim]);
  while(v[dim] > 0 && dim < MAX_ELEM){
    dim++;
    if(dim < MAX_ELEM)
      scanf("%d", &v[dim]);
  }

/* VERSIONE ALTERNATIVA */
/*
  scanf("%d", &v[dim]);
  while(v[dim] > 0 && dim < MAX_ELEM - 1){
    dim++;
    scanf("%d", &v[dim]);
  }
  if(v[dim] > 0)
  	dim++;
*/

  do
    scanf("%d",&k);
  while(k <= 0);

  ris = cercasomma(k, v, dim);

  printf("%d\n", ris);
  return 0;
}

int cercasomma(int somma, int dati[], int dim) {
  int i, j, found;

  for(i = 0; i < dim-1 && !found; i++)
    for(j = i+1; j < dim && !found; j++)
      if(dati[i] + dati[j] == somma)
        found = 1;

  return found;
}
