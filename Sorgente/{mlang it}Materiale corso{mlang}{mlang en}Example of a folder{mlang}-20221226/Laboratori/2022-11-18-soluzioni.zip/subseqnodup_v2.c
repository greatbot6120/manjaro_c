#include <stdio.h>

#define LMAX 30

int main(int argc, char * argv[])
{
  char seq[LMAX+1];
  int i, j, k, x;
  int finito, doppio;
  int dim, lenmax, startmax, endmax;

  scanf("%[^\n]", seq);
  printf("%s\n", seq);
  for(i = 0, lenmax = 0; seq[i] !='\0'; i++){ /*scorro tutte le possibili posizioni inziali*/
    for(j = i+1, doppio = 0; seq[j] != '\0' && !doppio; j++){ /*scorro dalla posizione iniziale per appendere un nuovo carattere alla sottostrings*/
      for(k = i; k < j && !doppio; k++) /*controllo che il nuovo carattere non sia uguale ad uno dei precedenti della sottostringa*/
        if(seq[k] == seq[j]){
          doppio = 1;
          j--;
        }
    }
    if(lenmax < j-i){
      lenmax = j - i;
      startmax = i;
      endmax = j - 1;
    }
    /* il seguente ciclo, facoltativo, serve per non interare inutilmente: quando si trova un carattere duplicato rispetto a seq[j] 
       si può far "saltare" la i al carattere successivo*/
    if(doppio){
      i = k - 1;
    }
  }

  printf("%s\n", seq);

  /* opzionale: stampo la sottostringa */
  for(i = 0; i < startmax; i++)
    printf(" ");
  for(i = startmax; i <= endmax; i++)
    printf("%c", seq[i]);
  printf("\n");

  printf("%d\n", lenmax);
  return 0;
}
