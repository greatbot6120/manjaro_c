#include <stdio.h>

#define N 5
#define UP 1
#define DOWN -1

void sortarr(int[], int, int);
void fillarr(int[], int);
int mixarr(int [], int [], int [], int, int);

int main(int argc, char * argv[])
{
	int seq1[N], seq2[N], unione[N*2];
	int nu, i;

	fillarr(seq1, N);
	fillarr(seq2, N);

	sortarr(seq1, N, UP);
	sortarr(seq2, N, UP);

	nu = mixarr(seq1, seq2, unione, N, UP);
	for(i = 0; i < nu; i++)
		printf("%d ", unione[i]);
	printf("\n");
	return 0;
}


void sortarr(int v[], int dim, int updown)
{
	int i, j;
	int tmp;

	if(updown == UP)
		for(i = 0; i < dim; i++){
			for(j = i+1; j < dim; j++)
				if(v[i] > v[j]){
					tmp = v[i];
					v[i] = v[j];
					v[j] = tmp;
				}
		}
	else
		for(i = 0; i < dim; i++){
			for(j = i+1; j < dim; j++)
				if(v[i] < v[j]){
					tmp = v[i];
					v[i] = v[j];
					v[j] = tmp;
				}
		}
}


void fillarr(int v[], int dim)
{
	int i;

	for(i =0; i< dim; i++)
		scanf("%d", &v[i]);
}

int mixarr(int v1[], int v2[], int u[], int dim, int updown)
{
	int i, j, k;

	i = 0;
	j = 0;
	k = 0;
	/* il primo valore */
	if(updown == UP)
		if(v1[i] <= v2[j]){
			u[k] = v1[i];
			i++;
		} else {
			u[k] = v2[j];
			j++;
		}
	else
		if(v1[i] >= v2[j]){
			u[k] = v1[i];
			i++;
		} else {
			u[k] = v2[j];
			j++;
		}
/* oppure al contrario
	if(v1[i] <= v2[j])
		if(updown == UP){
			u[k] = v1[i];
			i++;
		} else {
			u[k] = v2[j];
			j++;
		}
	else
		if(updown == UP){
			u[k] = v2[j];
			j++;
		} else {
			u[k] = v1[i];
			i++;
		}
*/
	k++;
	/* tutti gli altri */
	while(i < dim && j < dim){
		if(updown == UP)
			if(v1[i] < v2[j]){
				if(v1[i] != u[k]){
					u[k] = v1[i];
					k++;
				}
				i++;
			} else {
				if(v2[j] != u[k]){
					u[k] = v2[j];
					k++;
				}
				j++;
			}
		else
			if(v1[i] > v2[j]){
				if(v1[i] != u[k]){
					u[k] = v1[i];
					k++;
				}
				i++;
			} else {
				if(v2[j] != u[k]){
					u[k] = v2[j];
					k++;
				}
				j++;
			}
		/* anche qua si possono girare le condizioni */
	}
	for(; i < dim; i++){
		if(v1[i] != u[k]){
			u[k] = v1[i];
			k++;
		}
	}
	for(; j < dim; j++){
		if(v2[j] != u[k]){
			u[k] = v2[j];
			k++;
		}
	}
	return k;
}